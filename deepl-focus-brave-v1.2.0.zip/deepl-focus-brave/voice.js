(() => {
  "use strict";

  const html = document.documentElement;
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const onTranslator = () => /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?translator\/?$/i.test(location.pathname);
  const SOURCE = '[data-testid="translator-source-input"] [contenteditable="true"]';
  const NATIVE_MIC = [
    'button[data-testid*="dictation" i]',
    'button[data-testid*="microphone" i]',
    'button[data-testid*="voice-input" i]',
    'button[data-testid*="speech-input" i]',
    'button[data-testid*="speech-to-text" i]',
    'button:has([data-dui-component="Icon.Microphone"])'
  ].join(",");
  const locales = {
    tr: "tr-TR", en: "en-US", de: "de-DE", fr: "fr-FR", es: "es-ES",
    it: "it-IT", pt: "pt-PT", ru: "ru-RU", uk: "uk-UA", nl: "nl-NL",
    pl: "pl-PL", ja: "ja-JP", ko: "ko-KR", zh: "zh-CN",
    "zh-hans": "zh-CN", "zh-hant": "zh-TW", ar: "ar-SA"
  };
  let binding = null;
  let session = null;
  let bookmark = null;
  let nativeControl = null;
  let frame = 0;

  function language() {
    const selected = document.querySelector('[data-testid="translator-source-lang"][dl-selected-lang]')
      ?.getAttribute("dl-selected-lang");
    const code = selected && selected !== "auto"
      ? selected
      : navigator.language || html.lang || "tr-TR";
    const normalized = code.replaceAll("_", "-");
    if (locales[normalized.toLowerCase()]) return locales[normalized.toLowerCase()];
    try { return Intl.getCanonicalLocales(normalized)[0] || "tr-TR"; }
    catch { return "tr-TR"; }
  }

  function setStatus(message) {
    if (binding && binding.status.textContent !== message) binding.status.textContent = message;
  }

  function paint() {
    if (!binding) return;
    const pressed = Boolean(session && !session.stopping);
    const label = pressed ? "Sesle yazmayı durdur" : "Sesle yazmayı başlat";
    binding.button.setAttribute("aria-pressed", String(pressed));
    binding.button.setAttribute("aria-label", label);
    binding.button.title = label;
  }

  function cancel(message = "") {
    const previous = session;
    session = null;
    if (previous) {
      try { previous.recognition.abort(); }
      catch (error) { console.warn("DeepL Focus: mikrofon durdurulamadı", error); }
    }
    paint();
    if (message) setStatus(message);
  }

  function rememberSelection() {
    if (!binding) return;
    const selection = window.getSelection();
    if (!selection?.rangeCount) return;
    const range = selection.getRangeAt(0);
    if (binding.editor.contains(range.startContainer) && binding.editor.contains(range.endContainer)) {
      bookmark = range.cloneRange();
    }
  }

  function restoreCaret(editor) {
    editor.focus({ preventScroll: true });
    const range = bookmark && editor.contains(bookmark.startContainer) && editor.contains(bookmark.endContainer)
      ? bookmark.cloneRange()
      : document.createRange();
    if (!bookmark || !editor.contains(bookmark.startContainer) || !editor.contains(bookmark.endContainer)) {
      range.selectNodeContents(editor);
    }
    // Dictation adds text after a selection; it never deletes selected user text.
    range.collapse(false);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
    return range;
  }

  function insertTranscript(transcript) {
    const editor = binding?.editor;
    if (!editor?.isConnected) return false;
    const text = transcript.trim();
    if (!text) return true;
    rememberSelection();
    const range = restoreCaret(editor);
    const before = range.cloneRange();
    before.selectNodeContents(editor);
    before.setEnd(range.startContainer, range.startOffset);
    const after = range.cloneRange();
    after.selectNodeContents(editor);
    after.setStart(range.endContainer, range.endOffset);
    const prefix = before.toString().slice(-1);
    const suffix = after.toString().slice(0, 1);
    const addition = (prefix && !/\s/.test(prefix) && !/^[,.;:!?]/.test(text) ? " " : "") + text +
      (suffix && !/\s|[,.;:!?]/.test(suffix) ? " " : "");
    const original = editor.textContent;
    let inserted = false;
    try { inserted = document.execCommand("insertText", false, addition); }
    catch (error) { console.warn("DeepL Focus: yerel metin ekleme kullanılamadı", error); }

    if (!inserted && editor.textContent === original) {
      const allowed = editor.dispatchEvent(new InputEvent("beforeinput", {
        bubbles: true, composed: true, cancelable: true, inputType: "insertText", data: addition
      }));
      if (allowed) {
        const liveRange = restoreCaret(editor);
        const node = document.createTextNode(addition);
        liveRange.insertNode(node);
        liveRange.setStartAfter(node);
        liveRange.collapse(true);
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(liveRange);
        editor.dispatchEvent(new InputEvent("input", {
          bubbles: true, composed: true, inputType: "insertText", data: addition
        }));
      }
    }
    rememberSelection();
    return inserted || editor.textContent !== original;
  }

  const errors = {
    "not-allowed": "Mikrofon izni verilmedi. Brave site ayarlarından mikrofona izin verebilirsin.",
    "service-not-allowed": "Brave ses tanıma hizmetine erişemiyor. Tarayıcının ses girişi ayarlarını kontrol et.",
    "audio-capture": "Mikrofon bulunamadı veya kullanılamıyor.",
    network: "Ses tanıma hizmetine bağlanılamadı. Bağlantını kontrol edip yeniden dene.",
    "no-speech": "Ses algılanmadı. Yeniden deneyebilirsin.",
    "language-not-supported": "Seçili dil için ses tanıma desteklenmiyor.",
    aborted: "Sesle yazma durduruldu."
  };

  function toggle() {
    if (!binding) return;
    if (session) {
      if (session.stopping) return;
      session.stopping = true;
      paint();
      setStatus("Sesle yazma durduruluyor…");
      try { session.recognition.stop(); }
      catch { cancel("Sesle yazma durduruldu."); }
      return;
    }
    if (!Recognition) {
      setStatus("Bu tarayıcı ses girişini desteklemiyor.");
      return;
    }
    rememberSelection();
    restoreCaret(binding.editor);
    const current = { recognition: null, language: language(), finalResults: new Set(), stopping: false };
    try {
      current.recognition = new Recognition();
      current.recognition.lang = current.language;
      current.recognition.continuous = true;
      current.recognition.interimResults = true;
      session = current;
      current.recognition.onstart = () => {
        if (session === current && !current.stopping) setStatus("Dinleniyor…");
      };
      current.recognition.onresult = event => {
        if (session !== current || !binding?.editor.isConnected) return;
        if (!html.hasAttribute("data-dlf-active") || !onTranslator() ||
            language() !== current.language || document.visibilityState === "hidden") {
          cancel("Sesle yazma durduruldu.");
          return;
        }
        const interim = [];
        for (let i = 0; i < event.results.length; i++) {
          const result = event.results[i];
          const transcript = result[0]?.transcript || "";
          if (result.isFinal && !current.finalResults.has(i)) {
            current.finalResults.add(i);
            if (!insertTranscript(transcript)) {
              cancel("Metin eklenemedi. Çeviri alanına tıklayıp yeniden dene.");
              return;
            }
          } else if (!result.isFinal) interim.push(transcript);
        }
        setStatus(interim.length ? interim.join(" ") : "Dinleniyor…");
      };
      current.recognition.onerror = event => {
        if (session === current) cancel(errors[event.error] || "Ses girişi başlatılamadı. Yeniden deneyebilirsin.");
      };
      current.recognition.onend = () => {
        if (session !== current) return;
        session = null;
        paint();
        setStatus("Sesle yazma tamamlandı.");
      };
      paint();
      setStatus("Mikrofon başlatılıyor…");
      current.recognition.start();
    } catch (error) {
      console.warn("DeepL Focus: ses girişi başlatılamadı", error);
      cancel("Ses girişi başlatılamadı. Mikrofon iznini kontrol edip yeniden dene.");
    }
  }

  function detach() {
    cancel();
    binding?.button.remove();
    binding?.status.remove();
    binding = null;
    bookmark = null;
    nativeControl?.removeAttribute("data-dlf-native-dictation");
    nativeControl = null;
  }

  function reconcile() {
    frame = 0;
    const active = onTranslator() && html.hasAttribute("data-dlf-active");
    const root = active ? document.querySelector("[data-dlf-root]") : null;
    const source = root?.querySelector('[data-layout-id="editor-layout-source"]');
    const editor = source?.querySelector(SOURCE);
    const bar = source?.querySelector('[data-layout-id="editor-layout-action-bar"]');
    const native = source?.querySelector(NATIVE_MIC);
    if (native && !native.hasAttribute("data-dlf-dictation")) {
      detach();
      nativeControl = native;
      native.setAttribute("data-dlf-native-dictation", "");
      return;
    }
    if (!root || !editor || !bar) {
      detach();
      return;
    }
    if (binding && (binding.editor !== editor || binding.bar !== bar || !binding.button.isConnected)) detach();
    if (session && session.language !== language()) cancel("Kaynak dili değiştiği için sesle yazma durduruldu.");
    if (binding) return;
    const button = document.createElement("button");
    button.type = "button";
    button.setAttribute("data-dlf-dictation", "");
    button.setAttribute("aria-pressed", "false");
    button.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="2" width="6" height="13" rx="3"></rect><path d="M5 10v2a7 7 0 0 0 14 0v-2M12 19v3M8 22h8"></path></svg>';
    const status = document.createElement("span");
    status.setAttribute("data-dlf-voice-status", "");
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    status.setAttribute("aria-atomic", "true");
    binding = { root, source, editor, bar, button, status };
    button.addEventListener("pointerdown", event => {
      if (event.button !== 0) return;
      rememberSelection();
      event.preventDefault();
    });
    button.addEventListener("click", toggle);
    (bar.firstElementChild || bar).prepend(button);
    source.append(status);
    paint();
  }

  function schedule() {
    if (session && (!binding?.editor.isConnected || !onTranslator())) cancel();
    if (!frame) frame = requestAnimationFrame(reconcile);
  }

  document.addEventListener("selectionchange", rememberSelection);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") cancel("Sekme gizlendiği için sesle yazma durduruldu.");
  });
  new MutationObserver(schedule).observe(html, {
    childList: true, subtree: true, attributes: true,
    attributeFilter: ["data-dlf-active", "dl-selected-lang"]
  });
  window.addEventListener("popstate", schedule);
  window.addEventListener("hashchange", schedule);
  window.navigation?.addEventListener("currententrychange", schedule);
  window.addEventListener("pagehide", () => cancel());
  setInterval(() => {
    if (session && (!onTranslator() || session.language !== language())) schedule();
  }, 750);
  reconcile();
})();
