"use strict";

const STORAGE_KEY = "darkModeEnabled";
const DEFAULT_DARK_MODE = true;

// Keep click operations ordered, including while the service worker is starting.
let operationQueue = Promise.resolve();

async function showState(enabled) {
  await Promise.all([
    chrome.action.setBadgeText({ text: enabled ? "KOYU" : "AÇIK" }),
    chrome.action.setBadgeBackgroundColor({ color: enabled ? "#355b84" : "#6b4c0a" }),
    chrome.action.setTitle({
      title: enabled
        ? "DeepL Focus — Koyu tema açık. Açık temaya geçmek için tıkla."
        : "DeepL Focus — Açık tema açık. Koyu temaya geçmek için tıkla."
    })
  ]);
}

async function reportError(error) {
  console.error("DeepL Focus: Tema tercihi uygulanamadı.", error);
  try {
    await Promise.all([
      chrome.action.setBadgeText({ text: "!" }),
      chrome.action.setBadgeBackgroundColor({ color: "#b42318" }),
      chrome.action.setTitle({ title: "DeepL Focus — Tema değiştirilemedi. Yeniden tıkla." })
    ]);
  } catch (badgeError) {
    console.error("DeepL Focus: Hata göstergesi güncellenemedi.", badgeError);
  }
}

function enqueue(operation) {
  operationQueue = operationQueue.then(operation).catch(reportError);
  return operationQueue;
}

async function initialize() {
  const saved = await chrome.storage.local.get(STORAGE_KEY);
  let enabled = saved[STORAGE_KEY];
  if (typeof enabled !== "boolean") {
    enabled = DEFAULT_DARK_MODE;
    await chrome.storage.local.set({ [STORAGE_KEY]: enabled });
  }
  await showState(enabled);
}

chrome.runtime.onInstalled.addListener(() => enqueue(initialize));
chrome.runtime.onStartup.addListener(() => enqueue(initialize));

chrome.action.onClicked.addListener(() => {
  enqueue(async () => {
    const saved = await chrome.storage.local.get(STORAGE_KEY);
    const current = typeof saved[STORAGE_KEY] === "boolean"
      ? saved[STORAGE_KEY]
      : DEFAULT_DARK_MODE;
    const enabled = !current;
    await chrome.storage.local.set({ [STORAGE_KEY]: enabled });
    await showState(enabled);
  });
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local" || !Object.hasOwn(changes, STORAGE_KEY)) return;
  const enabled = changes[STORAGE_KEY].newValue;
  enqueue(() => showState(typeof enabled === "boolean" ? enabled : DEFAULT_DARK_MODE));
});

// Service workers are restarted independently of browser startup events.
enqueue(initialize);
