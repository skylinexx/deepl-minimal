(() => {
  "use strict";

  // Keep DeepL's live editor in place: moving/cloning it breaks React state.
  const KEY = "darkModeEnabled";
  const TARGET = '[aria-labelledby~="text-translator-section-heading"]';
  const FALLBACK = '[data-layout-id="editor-layout-root"]';
  const OVERLAYS = '[data-radix-popper-content-wrapper], [role="dialog"], [role="menu"], [role="listbox"], [role="tooltip"], [popover]';
  const html = document.documentElement;
  let dark = true;
  let root = null;
  let pendingFrame = 0;
  let interactionUntil = 0;
  let overlayBaseline = new Set();
  let allowInitialHide = true;
  let marked = new Map();
  const openedOverlays = new Set();

  const onTranslator = () => /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?translator\/?$/i.test(location.pathname);

  function clearMarks() {
    for (const [element, attributes] of marked) {
      for (const attribute of attributes) element.removeAttribute(attribute);
    }
    marked = new Map();
    openedOverlays.clear();
    root = null;
  }

  function reconcile() {
    pendingFrame = 0;
    if (!onTranslator()) {
      clearMarks();
      html.removeAttribute("data-dlf-active");
      html.removeAttribute("data-dlf-pending");
      html.removeAttribute("data-dlf-theme");
      return;
    }

    html.setAttribute("data-dlf-theme", dark ? "dark" : "light");
    const found = document.querySelector(TARGET) || document.querySelector(FALLBACK);
    if (!found || !document.body) {
      clearMarks();
      html.removeAttribute("data-dlf-active");
      html.toggleAttribute("data-dlf-pending", allowInitialHide);
      return;
    }

    root = found;
    const next = new Map();
    const mark = (element, attribute) => {
      if (!next.has(element)) next.set(element, new Set());
      next.get(element).add(attribute);
    };
    mark(root, "data-dlf-root");
    for (let parent = root.parentElement; parent && parent !== html; parent = parent.parentElement) {
      mark(parent, "data-dlf-path");
    }

    // Radix renders language pickers outside the editor. Only preserve portals
    // opened by an editor interaction, never unsolicited marketing dialogs.
    for (const overlay of openedOverlays) {
      if (!overlay.isConnected) openedOverlays.delete(overlay);
    }
    for (const candidate of document.querySelectorAll(OVERLAYS)) {
      if (root.contains(candidate) || candidate.contains(root)) continue;
      if (candidate.hidden || candidate.getAttribute("aria-hidden") === "true" ||
          candidate.getAttribute("data-state") === "closed") continue;
      const overlay = candidate.closest("[data-radix-popper-content-wrapper]") || candidate;
      const owner = candidate.id && [...root.querySelectorAll("[aria-controls]")]
        .some(button => button.getAttribute("aria-expanded") === "true" &&
          button.getAttribute("aria-controls").split(/\s+/).includes(candidate.id));
      if (owner || (performance.now() < interactionUntil && !overlayBaseline.has(candidate))) {
        openedOverlays.add(overlay);
      }
    }
    for (const overlay of openedOverlays) {
      if (root.contains(overlay)) continue;
      mark(overlay, "data-dlf-overlay");
      for (let parent = overlay.parentElement; parent && parent !== html; parent = parent.parentElement) {
        mark(parent, "data-dlf-overlay-path");
      }
    }

    for (const [element, attributes] of marked) {
      for (const attribute of attributes) {
        if (!next.get(element)?.has(attribute)) element.removeAttribute(attribute);
      }
    }
    for (const [element, attributes] of next) {
      for (const attribute of attributes) {
        if (!element.hasAttribute(attribute)) element.setAttribute(attribute, "");
      }
    }
    marked = next;
    html.setAttribute("data-dlf-active", "");
    html.removeAttribute("data-dlf-pending");
  }

  function schedule() {
    if (!pendingFrame) pendingFrame = requestAnimationFrame(reconcile);
  }

  function rememberInteraction(event) {
    const path = event.composedPath();
    if (root && (path.includes(root) || [...openedOverlays].some(overlay => path.includes(overlay)))) {
      if (performance.now() >= interactionUntil || event.type === "pointerdown" || event.type === "keydown") {
        overlayBaseline = new Set(document.querySelectorAll(OVERLAYS));
      }
      interactionUntil = performance.now() + 1800;
      schedule();
    }
  }

  if (onTranslator()) {
    html.setAttribute("data-dlf-theme", "dark");
    html.setAttribute("data-dlf-pending", "");
  }
  // Fail open if DeepL ever changes its editor markup or fails to load.
  setTimeout(() => {
    allowInitialHide = false;
    html.removeAttribute("data-dlf-pending");
  }, 4500);

  chrome.storage.local.get(KEY).then(result => {
    dark = result[KEY] !== false;
    schedule();
  }).catch(error => console.warn("DeepL Focus: tema tercihi okunamadı", error));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && KEY in changes) {
      dark = changes[KEY].newValue !== false;
      schedule();
    }
  });

  new MutationObserver(schedule).observe(html, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["aria-expanded", "data-state", "hidden", "open"]
  });
  for (const type of ["pointerdown", "click", "focusin", "keydown"]) {
    document.addEventListener(type, rememberInteraction, true);
  }
  window.addEventListener("popstate", schedule);
  window.addEventListener("hashchange", schedule);
  window.navigation?.addEventListener("currententrychange", schedule);
  // Also handle history changes made in the page's separate JavaScript world.
  let lastURL = location.href;
  setInterval(() => {
    if (lastURL !== location.href) {
      lastURL = location.href;
      schedule();
    }
  }, 1000);
  reconcile();
})();
