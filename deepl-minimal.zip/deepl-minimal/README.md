# DeepL Sade Gorunum

Bu Chrome eklentisi `https://www.deepl.com/tr/translator` sayfasinda otomatik calisir. Sayfa acildiginda sadece `main[data-layout-id="mainSection"]` alani gorunur, geri kalan kisimlar gizlenir.

## Kurulum

1. Chrome'da `chrome://extensions` sayfasini ac.
2. Sag ustten `Developer mode` secenegini aktif et.
3. `Load unpacked` butonuna tikla.
4. Masaustundeki `/Users/erdal.arikan/Desktop/deepl-sade-gorunum-extension` klasorunu sec.

## Kullanim

- DeepL ceviri sayfasini ac: `https://www.deepl.com/tr/translator`
- Eklenti otomatik olarak devreye girer.
- Herhangi bir butona tiklaman gerekmez.

## Notlar

- Eklenti sadece `deepl.com` uzerinde yuklenir.
- Etki alani pratikte yalnizca `/tr/translator` yoludur.
- DeepL arayuzu ciddi sekilde degisirse `main[data-layout-id="mainSection"]` secicisini guncellemek gerekebilir.
