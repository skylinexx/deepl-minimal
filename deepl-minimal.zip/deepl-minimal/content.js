const TARGET_PATH = "/tr/translator";
const KEEP_SELECTOR = 'main[data-layout-id="mainSection"]';
const STYLE_ID = "deepl-sade-gorunum-style";
const ACTIVE_ATTR = "data-deepl-sade-gorunum";
let isUpdateQueued = false;

function injectStyle() {
  if (document.getElementById(STYLE_ID)) {
    return;
  }

  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = `
    html[${ACTIVE_ATTR}="on"],
    html[${ACTIVE_ATTR}="on"] body {
      margin: 0 !important;
      padding: 0 !important;
      min-height: 100vh !important;
      background: #ffffff !important;
      overflow-x: hidden !important;
    }

    html[${ACTIVE_ATTR}="on"] body *:not(:has(${KEEP_SELECTOR})):not(${KEEP_SELECTOR}):not(${KEEP_SELECTOR} *) {
      display: none !important;
    }

    html[${ACTIVE_ATTR}="on"] body *:has(${KEEP_SELECTOR}) {
      width: 100% !important;
      max-width: none !important;
      margin: 0 !important;
    }

    html[${ACTIVE_ATTR}="on"] ${KEEP_SELECTOR} {
      display: block !important;
      width: 100% !important;
      max-width: none !important;
      min-height: 100vh !important;
      margin: 0 auto !important;
      isolation: isolate !important;
    }
  `;

  (document.head || document.documentElement).appendChild(style);
}

function shouldActivate() {
  return window.location.pathname === TARGET_PATH;
}

function hasTargetArea() {
  return Boolean(document.querySelector(KEEP_SELECTOR));
}

function updateState() {
  injectStyle();

  if (shouldActivate() && hasTargetArea()) {
    document.documentElement.setAttribute(ACTIVE_ATTR, "on");
    return;
  }

  document.documentElement.removeAttribute(ACTIVE_ATTR);
}

function scheduleUpdate() {
  if (isUpdateQueued) {
    return;
  }

  isUpdateQueued = true;
  window.requestAnimationFrame(() => {
    isUpdateQueued = false;
    updateState();
  });
}

function watchUrlChanges() {
  const methods = ["pushState", "replaceState"];

  for (const method of methods) {
    const original = history[method];

    history[method] = function patchedHistoryState(...args) {
      const result = original.apply(this, args);
      scheduleUpdate();
      return result;
    };
  }

  window.addEventListener("popstate", scheduleUpdate);
  window.addEventListener("hashchange", scheduleUpdate);
}

function watchDomChanges() {
  const observer = new MutationObserver(() => {
    if (!shouldActivate()) {
      if (document.documentElement.hasAttribute(ACTIVE_ATTR)) {
        document.documentElement.removeAttribute(ACTIVE_ATTR);
      }
      return;
    }

    if (!document.documentElement.hasAttribute(ACTIVE_ATTR) || !hasTargetArea()) {
      scheduleUpdate();
    }
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });
}

watchUrlChanges();
watchDomChanges();
scheduleUpdate();
window.addEventListener("load", scheduleUpdate, { once: true });
